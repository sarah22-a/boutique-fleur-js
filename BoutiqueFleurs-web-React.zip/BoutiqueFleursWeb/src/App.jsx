import { AuthProvider } from './controllers/AuthContext';
import { RacineController } from './controllers/RacineController';

// App.jsx ne fait qu'assembler : le fournisseur d'authentification, puis le contrôleur racine
export default function App() {
  return (
    <AuthProvider>
      <RacineController />
    </AuthProvider>
  );
}
