import { useState } from 'react';
import { formaterPrix } from '../../utils/texte';

// Vue : champ « code promo » du panier. La saisie et le message sont un état d'affichage ;
// la vérification du code est faite par le contrôleur (onAppliquer renvoie { ok, message }).
export const CodePromo = ({ codeActif, remise, onAppliquer, onRetirer }) => {
  const [saisie, setSaisie] = useState('');
  const [retour, setRetour] = useState(null);

  const appliquer = (e) => {
    e.preventDefault();
    const resultat = onAppliquer(saisie);
    setRetour(resultat);
    if (resultat.ok) setSaisie('');
  };

  if (codeActif) {
    return (
      <div className="promo promo--actif">
        <div>
          <p className="promo__code">{codeActif}</p>
          <p className="texte-doux">
            {remise > 0 ? `Vous économisez ${formaterPrix(remise)}` : "Ce code n'est plus valable pour ce montant"}
          </p>
        </div>
        <button type="button" className="lien lien--doux" onClick={() => { onRetirer(); setRetour(null); }}>
          Retirer
        </button>
      </div>
    );
  }

  return (
    <form className="promo" onSubmit={appliquer} noValidate>
      <label htmlFor="code-promo" className="promo__label">Code promo</label>
      <div className="promo__ligne">
        <input
          id="code-promo"
          className="champ champ--plein"
          placeholder="PETALE10"
          autoComplete="off"
          autoCapitalize="characters"
          value={saisie}
          onChange={(e) => { setSaisie(e.target.value); setRetour(null); }}
        />
        <button type="submit" className="bouton bouton--contour">Appliquer</button>
      </div>
      {retour && !retour.ok && <p className="erreur" role="alert">{retour.message}</p>}
    </form>
  );
};
