// Vue : `onglets` = [{ id, libelle, compte }], `onglet` = id de l'onglet actif
export const BarreOnglets = ({ onglets, onglet, onChange }) => (
  <nav className="onglets" aria-label="Navigation principale">
    {onglets.map((o) => {
      const actif = onglet === o.id;
      return (
        <button
          key={o.id}
          type="button"
          className={`onglet${actif ? ' onglet--actif' : ''}`}
          onClick={() => onChange(o.id)}
          aria-current={actif ? 'page' : undefined}
        >
          <span className="onglet__ligne">
            {o.libelle}
            {o.compte > 0 && <span className="pastille">{o.compte}</span>}
          </span>
          <span className="onglet__point" />
        </button>
      );
    })}
  </nav>
);
