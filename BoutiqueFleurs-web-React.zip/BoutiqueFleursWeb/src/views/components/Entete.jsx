import { useState, useEffect } from 'react';

// Vue : reçoit l'utilisateur et la fonction de déconnexion en props.
// `ouvert` (menu du compte) est un état d'affichage : il reste dans la vue.
export const Entete = ({ utilisateur, onDeconnexion, onProfil }) => {
  const [ouvert, setOuvert] = useState(false);

  useEffect(() => {
    if (!ouvert) return undefined;
    const fermerAvecEchap = (e) => e.key === 'Escape' && setOuvert(false);
    window.addEventListener('keydown', fermerAvecEchap);
    return () => window.removeEventListener('keydown', fermerAvecEchap);
  }, [ouvert]);

  return (
    <header className="entete">
      <div className="entete__contenu">
        <span className="marque">Maison Pétale</span>

        <div className="compte">
          <button
            type="button"
            className="avatar"
            onClick={() => setOuvert((o) => !o)}
            aria-haspopup="true"
            aria-expanded={ouvert}
            aria-label={`Compte de ${utilisateur.prenom}`}
          >
            {utilisateur.prenom.charAt(0).toUpperCase()}
          </button>

          {ouvert && (
            <>
              <button type="button" className="compte__fond" aria-label="Fermer" onClick={() => setOuvert(false)} />
              <div className="compte__menu">
                <p className="compte__nom">{utilisateur.prenom} {utilisateur.nom}</p>
                <p className="compte__email">{utilisateur.email}</p>
                {utilisateur.role === 'admin' && <p className="compte__role">Compte administrateur</p>}
                <button
                  type="button"
                  className="compte__action"
                  onClick={() => {
                    setOuvert(false);
                    onProfil();
                  }}
                >
                  Mon profil
                </button>
                <button type="button" className="compte__action compte__action--doux" onClick={onDeconnexion}>
                  Se déconnecter
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
};
