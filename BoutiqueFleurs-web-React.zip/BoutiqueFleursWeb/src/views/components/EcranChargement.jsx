export const EcranChargement = () => (
  <div className="plein-ecran" role="status" aria-label="Chargement">
    <span className="spinner" />
  </div>
);
