import { memo } from 'react';
import { PhotoProduit } from './PhotoProduit';
import { formaterPrix } from '../../utils/texte';

const LignePanier = ({ ligne, max, onChangerQuantite, onRetirer }) => (
  <li className="ligne">
    <PhotoProduit produit={ligne} petite />

    <div className="ligne__contenu">
      <div className="ligne__haut">
        <h3 className="ligne__nom">{ligne.nom}</h3>
        <span className="prix">{formaterPrix(ligne.prix * ligne.quantite)}</span>
      </div>
      <p className="ligne__unite">{formaterPrix(ligne.prix)} l'unité</p>

      <div className="ligne__bas">
        <div className="quantite">
          <button
            type="button"
            className="quantite__pas"
            disabled={ligne.quantite <= 1}
            onClick={() => onChangerQuantite(ligne, -1)}
            aria-label="Retirer un exemplaire"
          >
            −
          </button>
          <span className="quantite__nombre">{ligne.quantite}</span>
          <button
            type="button"
            className="quantite__pas"
            disabled={ligne.quantite >= max}
            onClick={() => onChangerQuantite(ligne, 1)}
            aria-label="Ajouter un exemplaire"
          >
            +
          </button>
        </div>

        <button type="button" className="lien lien--doux" onClick={() => onRetirer(ligne.id)}>
          Supprimer
        </button>
      </div>
    </div>
  </li>
);

export default memo(LignePanier);
