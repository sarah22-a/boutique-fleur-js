// Vue : page de connexion ou d'inscription (children) et lien pour passer de l'une à l'autre
export const InviteLayout = ({ ecran, onBasculer, children }) => (
  <div className="invite">
    <div className="invite__carte">{children}</div>
    <p className="invite__lien">
      <button type="button" className="lien" onClick={onBasculer}>
        {ecran === 'login' ? "Pas encore de compte ? S'inscrire" : 'Déjà inscrit ? Se connecter'}
      </button>
    </p>
  </div>
);
