import { Entete } from '../components/Entete';
import { BarreOnglets } from '../components/BarreOnglets';

// Vue : en-tête, pages, onglets. `pages` = { idPage: élément }.
// Toutes les pages restent montées (attribut hidden) : la recherche n'est pas perdue en changeant d'onglet.
export const BoutiqueLayout = ({
  utilisateur, onDeconnexion, onProfil, onglets, onglet, onChangerOnglet, pages,
}) => (
  <div className="boutique">
    <Entete utilisateur={utilisateur} onDeconnexion={onDeconnexion} onProfil={onProfil} />

    <main className="boutique__contenu">
      {Object.entries(pages).map(([id, page]) => (
        <section key={id} hidden={onglet !== id}>
          {page}
        </section>
      ))}
    </main>

    <BarreOnglets onglets={onglets} onglet={onglet} onChange={onChangerOnglet} />
  </div>
);
