import ProduitCard from '../components/ProduitCard';
import { FicheProduit } from '../components/FicheProduit';

// Vue : les favoris. Tout arrive par props depuis FavorisController.
export const FavorisScreen = ({
  produits, chargement, erreur, quantites, favoris, produitOuvert,
  onOuvrir, onFermer, onToggleFavori, onAjouter, onReessayer, onCatalogue,
}) => (
  <div className="page">
    <header className="page__entete">
      <h1 className="titre-page">Favoris</h1>
      {produits.length > 0 && (
        <p className="texte-doux">{produits.length} fleur{produits.length > 1 ? 's' : ''} préférée{produits.length > 1 ? 's' : ''}</p>
      )}
    </header>

    {chargement && <div className="centre"><span className="spinner" role="status" aria-label="Chargement" /></div>}

    {!chargement && erreur && (
      <div className="centre">
        <p className="erreur">{erreur}</p>
        <button type="button" className="bouton" onClick={onReessayer}>Réessayer</button>
      </div>
    )}

    {!chargement && !erreur && produits.length === 0 && (
      <div className="vide-zone">
        <h2>Pas encore de favori</h2>
        <p className="texte-doux">Touchez l'étoile d'une fleur pour la retrouver ici.</p>
        <button type="button" className="bouton" onClick={onCatalogue}>Voir le catalogue</button>
      </div>
    )}

    {!chargement && !erreur && produits.length > 0 && (
      <ul className="grille grille--haut">
        {produits.map((p) => (
          <li key={p.id}>
            <ProduitCard
              produit={p}
              quantite={quantites[p.id] ?? 0}
              estFavori
              onAjouter={onAjouter}
              onToggleFavori={onToggleFavori}
              onOuvrir={onOuvrir}
            />
          </li>
        ))}
      </ul>
    )}

    <FicheProduit
      produit={produitOuvert}
      quantite={produitOuvert ? quantites[produitOuvert.id] ?? 0 : 0}
      estFavori={produitOuvert ? favoris.includes(produitOuvert.id) : false}
      onFermer={onFermer}
      onAjouter={onAjouter}
      onToggleFavori={onToggleFavori}
    />
  </div>
);
