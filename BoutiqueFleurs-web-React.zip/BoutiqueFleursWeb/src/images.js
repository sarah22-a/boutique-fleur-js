// Photos des fleurs : aucune pour l'instant. Un produit sans photo affiche un fond rose avec son initiale.
// Pour ajouter VOS photos : déposez public/fleurs/1.jpg, 2.jpg ... (une image par produit, nommée avec son id,
// portrait 4:5, 600 px ou plus), puis mettez ici le nombre de photos (ex. 12).
//
//  1 Bouquet de roses roses   5 Roses poudrées (12 tiges)   9 Eucalyptus (botte)
//  2 Pivoines blush           6 Orchidée blanche           10 Gypsophile séchée
//  3 Tulipes pastel           7 Lys rose                   11 Renoncules corail
//  4 Bouquet champêtre        8 Hortensia rose             12 Pampa séché
const NOMBRE_PHOTOS = 0;

export const aUnePhoto = (produitId) => produitId >= 1 && produitId <= NOMBRE_PHOTOS;
export const urlPhoto = (produitId) => `${import.meta.env.BASE_URL}fleurs/${produitId}.jpg`;
