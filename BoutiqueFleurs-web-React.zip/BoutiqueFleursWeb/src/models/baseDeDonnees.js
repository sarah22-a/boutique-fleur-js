import { normaliser } from '../utils/texte';

// La "base de données" du site : un objet JSON enregistré dans localStorage.
// Les fonctions du modèle sont toutes asynchrones, comme avec SQLite sur mobile :
// les contrôleurs (hooks) sont donc les mêmes dans les deux versions.
const CLE = 'maison-petale-bdd';

export const QUANTITE_MAX = 10;
export const ADMIN_EMAIL = 'admin@maisonpetale.fr';
export const ADMIN_MDP = 'AdminPetale2026';

// [nom, catégorie, prix, stock]
const FLEURS = [
  ['Bouquet de roses roses', 'Bouquets', 39, 15],
  ['Pivoines blush', 'Bouquets', 45, 8],
  ['Tulipes pastel', 'Bouquets', 25, 20],
  ['Bouquet champêtre', 'Bouquets', 32, 12],
  ['Renoncules corail', 'Bouquets', 28, 0],
  ['Roses poudrées (12 tiges)', 'Roses', 49, 10],
  ['Lys rose', 'Roses', 29, 14],
  ['Orchidée blanche', 'Plantes', 35, 6],
  ['Hortensia rose', 'Plantes', 27, 9],
  ['Eucalyptus (botte)', 'Feuillage', 12, 30],
  ['Gypsophile séchée', 'Séchées', 15, 25],
  ['Pampa séché', 'Séchées', 18, 0],
];

let base = null;
let initPromise = null;

export const sauverBase = () => {
  localStorage.setItem(CLE, JSON.stringify(base));
};

// Numéro suivant d'une table (comme AUTOINCREMENT)
export const prochainId = (table) => base.suivant[table]++;

// Appelable plusieurs fois : la base n'est préparée qu'une seule fois
export const initDb = () => {
  if (!initPromise) {
    initPromise = (async () => {
      try {
        base = JSON.parse(localStorage.getItem(CLE));
      } catch {
        base = null;
      }
      if (!base) {
        base = {
          utilisateurs: [], produits: [], panier: [], favoris: [],
          session: null, suivant: { utilisateurs: 1, produits: 1 },
        };
      }

      if (base.produits.length === 0) {
        for (const [nom, categorie, prix, stock] of FLEURS) {
          base.produits.push({
            id: prochainId('produits'), nom, nom_norm: normaliser(nom), categorie, prix, stock,
          });
        }
      }

      if (!base.utilisateurs.some((u) => u.role === 'admin')) {
        base.utilisateurs.push({
          id: prochainId('utilisateurs'), nom: 'Pétale', prenom: 'Admin',
          email: ADMIN_EMAIL, telephone: null, mdp: ADMIN_MDP,
          newsletter: 0, cgu: 1, role: 'admin', cree_le: new Date().toISOString(),
        });
      }

      sauverBase();
    })();
  }
  return initPromise;
};

// Renvoie la base prête à l'emploi (les fonctions du modèle l'utilisent)
export const ouvrirBase = async () => {
  await initDb();
  return base;
};
