# Maison Pétale, version web (React + Vite)

Même boutique que l'appli mobile, avec la **même architecture MVC, les mêmes hooks et les mêmes props**.
Seule la couche « modèle » change : le site enregistre ses données dans le navigateur (localStorage)
au lieu de SQLite.

## Lancer
    npm install
    npm run dev
puis ouvrir l'adresse affichée (http://localhost:5173).

## Comptes
- Administrateur (créé au premier chargement) : `admin@maisonpetale.fr` / `AdminPetale2026`
  → onglet **Admin** : ajouter, modifier, supprimer un produit, ajuster le stock.
- Les clients créent un compte depuis la page d'inscription (mot de passe de 12 caractères minimum).

## Fonctionnalités ajoutées
- **Fiche produit** : touchez une photo ou un nom pour ouvrir la fiche (description, conseil d'entretien, stock, ajout au panier, favori).
- **Favoris** : nouvel onglet avec les fleurs marquées d'une étoile.
- **Code promo** dans le panier : `PETALE10` (-10 %) et `BIENVENUE5` (-5 € dès 30 € d'achat), défini dans `utils/commande.js`.
- **Profil** (pastille en haut à droite, « Mon profil ») : modifier prénom, nom, téléphone.

## Architecture MVC
    src/models/        MODÈLE : accès aux données (localStorage), fonctions asynchrones
    src/views/         VUE : affichage seul (JSX + classes CSS). Données et fonctions arrivent en props
      screens/           Login, Inscription, Catalogue, Panier, Admin
      components/        Entete, BarreOnglets, ProduitCard, LignePanier, PhotoProduit, BarreRecherche...
      layouts/           InviteLayout, BoutiqueLayout
    src/controllers/   CONTRÔLEUR : hooks (logique) + composants qui relient hook et vue
      useLogin, useInscription, useCatalogue, useAdminProduits   -> hooks
      LoginController, InscriptionController, CatalogueController,
      PanierController, AdminController                           -> hook + props vers la vue
      AuthContext, PanierContext                                  -> état partagé (useAuth, usePanier)
      RacineController, InviteController, BoutiqueController      -> navigation
    src/utils/         validation.js, texte.js
    src/styles.css     tout le style (thème rose poudré, variables CSS)

## Passer de la version web à la version mobile (et inversement)
- `controllers/` : identique (même hooks, mêmes props). Seuls les noms de fichiers changent (.jsx).
- `models/` : localStorage (web) ↔ SQLite (mobile), mêmes noms de fonctions.
- `views/` : balises HTML (`div`, `button`, `input`) ↔ composants React Native (`View`, `Pressable`, `TextInput`).
- Style : `styles.css` ↔ `StyleSheet.create`.

## Photos
Le site n'a pas de photo pour l'instant : chaque fleur affiche son initiale sur fond rose.
Pour ajouter les vôtres : déposez `public/fleurs/1.jpg`, `2.jpg`... (une image par produit, nommée avec son id,
portrait 4:5, 600 px ou plus), puis mettez le nombre de photos dans `src/images.js` (`NOMBRE_PHOTOS`).

## Réinitialiser les données
Dans la console du navigateur : `localStorage.removeItem('maison-petale-bdd')`, puis recharger la page.

## Attention
Mots de passe en clair dans le navigateur et rôle admin vérifié côté client : usage d'apprentissage uniquement.
Pour un vrai site, il faudrait un serveur (Node/Express + base de données) et des mots de passe hachés.
